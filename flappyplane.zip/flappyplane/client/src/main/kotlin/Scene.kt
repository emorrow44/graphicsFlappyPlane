import org.w3c.dom.HTMLCanvasElement
import org.khronos.webgl.WebGLRenderingContext as GL //# GL# we need this for the constants declared ˙HUN˙ a constansok miatt kell
import kotlin.js.Date
import vision.gears.webglmath.UniformProvider
import vision.gears.webglmath.Vec1
import vision.gears.webglmath.Vec2
import vision.gears.webglmath.Vec3
import vision.gears.webglmath.Vec4
import vision.gears.webglmath.Mat4
import vision.gears.webglmath.*
import kotlin.math.exp
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.cos
import kotlin.math.*
import kotlin.random.Random

class Scene (
  val gl : WebGL2RenderingContext)  : UniformProvider("scene") {

  var message = ""

  var score = 0

  val vsTextured = Shader(gl, GL.VERTEX_SHADER, "textured-vs.glsl")
  val fsTextured = Shader(gl, GL.FRAGMENT_SHADER, "textured-fs.glsl")
  val texturedProgram = Program(gl, vsTextured, fsTextured)

  val vsTrafo = Shader(gl, GL.VERTEX_SHADER, "trafo-vs.glsl")
  val fsSolid = Shader(gl, GL.FRAGMENT_SHADER, "solid-fs.glsl")  
  val solidProgram = Program(gl, vsTrafo, fsSolid)

  val vsQuad = Shader(gl, GL.VERTEX_SHADER, "quad-vs.glsl")
  val fsBackground = Shader(gl, GL.FRAGMENT_SHADER, "background-fs.glsl")
  val backgroundProgram = Program(gl, vsQuad, fsBackground)
  val envTexture = TextureCube(gl,
    "media/sky1.png",
    "media/sky2.png",
    "media/sky3.png",
    "media/sky4.png",
    "media/sky5.png",
    "media/sky6.png"
    )
  val backgroundMaterial = Material(backgroundProgram).apply{
    this["envTexture"]?.set(envTexture)
  }

  val quadGeometry = TexturedQuadGeometry(gl)
  val donutGeometry = DonutGeometry(gl)

  // val groundMaterial = Material(texturedProgram).apply{
  //   this["colorTexture"]?.set(Texture2D(gl, "media/grass.jpeg"))
  //   this["envTexture"]?.set(envTexture)
  // }

  val pinkMaterial = Material(solidProgram).apply{
    this["solidColor"]?.set(1.0f, 0.7f, 0.2f, 0.5f)
  }

  val greenMaterial = Material(solidProgram).apply{
    this["solidColor"]?.set(0.0f, 1.0f, 0.0f, 0.5f)
  }

  //val groundMesh = Mesh(groundMaterial, GroundGeometry(gl))

  val donutMesh = Mesh(pinkMaterial, donutGeometry)

  val backgroundMesh = Mesh(backgroundMaterial, quadGeometry)

  val jsonLoader = JsonLoader()

  val thunderboltMeshes = jsonLoader.loadMeshes(gl,
    "media/thunderbolt_body.json",
    Material(texturedProgram).apply{
      this["colorTexture"]?.set(Texture2D(gl, "media/heli/heli.png"))
      this["envTexture"]?.set(envTexture)
    }
  )

  val gameObjects = ArrayList<GameObject>()
  val hoops = ArrayList<GameObject>()
  val completeHoops = ArrayList<GameObject>()

  var heli = GameObject(*thunderboltMeshes).apply{
    scale.set(0.5f,0.5f,0.5f)
    position.set(0f, 0f,17f)
    yaw += -3.15f
    move = object : GameObject.Motion(){
    override operator fun invoke(dt : Float, t : Float,
        keysPressed : Set<String>, gameObjects : List<GameObject>):Boolean {

      val gravity = Vec3(0f, 0f, 0f) 

      var rotarAxisDir = Vec3((Vec4(0f, 1f, 0f, 0f) * modelMatrix).xyz)
      acceleration = gravity + rotarAxisDir * lift.y 
      velocity += acceleration * dt
      position += velocity * dt
      
      return true
      }
    }
  }
  
  init {

    gameObjects += heli

    initHoops()

  }

  val camera = PerspectiveCamera(*Program.all).apply{
    position.set(0f, 0f, 0f)
    yaw = -3.15f
    update()
  }

  fun resize(canvas : HTMLCanvasElement) {
    gl.viewport(0, 0, canvas.width, canvas.height)//#viewport# tell the rasterizer which part of the canvas to draw to ˙HUN˙ a raszterizáló ide rajzoljon
    camera.setAspectRatio(canvas.width.toFloat()/canvas.height)
  }

  val timeAtFirstFrame = Date().getTime()
  var timeAtLastFrame =  timeAtFirstFrame

  init{
    //LABTODO: enable depth test
    gl.enable(GL.DEPTH_TEST)
    addComponentsAndGatherUniforms(*Program.all)
  }

  fun initHoops() {
    for(i in 11 downTo 1){
      hoops += GameObject(donutMesh).apply{
        scale.set(11.0f, 11.0f, 11.0f)
        position.set((Random.nextFloat()*32f) - 25f , (Random.nextFloat()*32f)-20f, 50.0f * i)
      }
    }
  }

  fun endGame() {
    if(score > 7) {
      message = "YOU WIN!!! \n TOTAL SCORE: " + score
    }else{
      message = "GAME OVER :( \n TOTAL SCORE: " + score
    }
  }
 
  @Suppress("UNUSED_PARAMETER")
  fun update(keysPressed : Set<String>) {
    val timeAtThisFrame = Date().getTime() 
    val dt = (timeAtThisFrame - timeAtLastFrame).toFloat() / 1000.0f
    val t = (timeAtThisFrame - timeAtFirstFrame).toFloat() / 1000.0f
    timeAtLastFrame = timeAtThisFrame

    message = "Score: " + score.toString()

    hoops.forEach{
      if(((it.position + Vec3(5.0f, 5.0f, 5.0f)) - heli.position).length() < 3.3f) {
        score += 1
        completeHoops.add(it)
        hoops.remove(it)
      }
    }

    camera.move(dt, keysPressed)

    camera.position.z += 0.2f
    heli.position.z += 0.2f
    heli.position.y -= 0.03f

    if ("I" in keysPressed){
      heli.pitch += 0.02f
      heli.position.y += 0.1f
    }
    if ("K" in keysPressed){
      heli.pitch -= 0.02f
      heli.position.y -= 0.1f
    }
    if("Q" in keysPressed){
      heli.position.y += 0.2f 
    }
    if ("O" in keysPressed){
      heli.roll -= 0.02f
      heli.position.x -= 0.2f
    }
    if ("U" in keysPressed){
      heli.roll += 0.02f
      heli.position.x += 0.2f
    }

    if(heli.position.z > 560f){
      endGame()
    }

    heli.roll *= 0.98f
    heli.pitch *= 0.98f
    
    gl.clearColor(0.3f, 0.0f, 0.3f, 1.0f)//## red, green, blue, alpha in [0, 1]
    gl.clearDepth(1.0f)//## will be useful in 3D ˙HUN˙ 3D-ben lesz hasznos
    gl.clear(GL.COLOR_BUFFER_BIT or GL.DEPTH_BUFFER_BIT)//#or# bitwise OR of flags

    gl.enable(GL.BLEND)
    gl.blendFunc(
      GL.SRC_ALPHA,
      GL.ONE_MINUS_SRC_ALPHA)

    backgroundMesh.draw(camera)

    gameObjects.forEach{ it.move(dt, t, keysPressed, gameObjects) }
    hoops.forEach{ it.move(dt, t, keysPressed, gameObjects) }

    gameObjects.forEach{ it.update() }
    gameObjects.forEach{ it.draw(this, camera) }

    hoops.forEach{ it.update() }
    hoops.forEach{ it.draw(this, camera) }

    completeHoops.forEach{it.using(greenMaterial).draw(this, camera)}
    completeHoops.forEach{it.update()}

  }

}
