import org.khronos.webgl.WebGLRenderingContext as GL
import org.khronos.webgl.Float32Array
import org.khronos.webgl.Uint16Array
import kotlin.math.sin
import kotlin.math.cos
import kotlin.math.PI
import vision.gears.webglmath.Geometry

class DonutGeometry(val gl : WebGL2RenderingContext) : Geometry(){

  val vertexBuffer = gl.createBuffer()
  init{
    gl.bindBuffer(GL.ARRAY_BUFFER, vertexBuffer) //#ARRAY_BUFFER# OpenGL dictionary:; array buffer means vertex buffer #bind# OpenGL phraseology:; Binding means: select as current. Further operations on the same target affect the bound resource.
    val vertexData = ArrayList<Float>()
    for(i in 0..100){
      val t = i /100.0f * 2.0f * PI.toFloat()
      if(i%2 == 0) {
        vertexData.add(((2.0f*cos(t) + 2.0f*sin(t)) * cos(t)) * 0.6f)
        vertexData.add(((2.0f*cos(t) + 2.0f*sin(t)) * sin(t)) * 0.6f)
        vertexData.add(0.5f)
      }
      else{
        vertexData.add((((2.0f*cos(t) + 2.0f*sin(t)) * cos(t)) * 0.2f) + 0.4f)
        vertexData.add((((2.0f*cos(t) + 2.0f*sin(t)) * sin(t)) * 0.2f) + 0.4f)
        vertexData.add(0.5f)
      }
      
    }
    gl.bufferData(GL.ARRAY_BUFFER,
      Float32Array( vertexData.toTypedArray()),
      GL.STATIC_DRAW)
  }

  val vertexColorBuffer = gl.createBuffer()
  init{
    gl.bindBuffer(GL.ARRAY_BUFFER, vertexColorBuffer) //#ARRAY_BUFFER# OpenGL dictionary:; array buffer means vertex buffer #bind# OpenGL phraseology:; Binding means: select as current. Further operations on the same target affect the bound resource.
    val vertexData = ArrayList<Float>()
    for(i in 0..100){
      val t = i /100.0f * 2.0f * PI.toFloat()
      if(i%2 == 0) {
        vertexData.add(((2.0f*cos(t) + 2.0f*sin(t)) * cos(t)) * 0.6f)
        vertexData.add(((2.0f*cos(t) + 2.0f*sin(t)) * sin(t)) * 0.6f)
        vertexData.add(0.5f)
      }
      else{
        vertexData.add((((2.0f*cos(t) + 2.0f*sin(t)) * cos(t)) * 0.2f) + 0.4f)
        vertexData.add((((2.0f*cos(t) + 2.0f*sin(t)) * sin(t)) * 0.2f) + 0.4f)
        vertexData.add(0.5f)
      }
      
    }
    gl.bufferData(GL.ARRAY_BUFFER,
      Float32Array( vertexData.toTypedArray()),
      GL.STATIC_DRAW)
  }

  val indexBuffer = gl.createBuffer()
  init{
    gl.bindBuffer(GL.ELEMENT_ARRAY_BUFFER, indexBuffer) //#ELEMENT_ARRAY_BUFFER# OpenGL dictionary:; element array buffer: index buffer
      var counterOne = 0
      var counterTwo = 1
      var counterThree = 2
      val indexData = ArrayList<Short>(150)

      for(i in 0..50){
        indexData.add(counterOne.toShort())
        indexData.add(counterTwo.toShort())
        indexData.add(counterThree.toShort())
        counterOne += 1
        counterTwo += 1
        counterThree += 1
      }

      gl.bufferData(GL.ELEMENT_ARRAY_BUFFER,
        Uint16Array( Array<Short>(150) {
        i : Int ->
        when(i%3){
          0 -> indexData[i].toShort() 
          1 ->indexData[i].toShort() 
          else -> indexData[i].toShort()} 

        }),
      GL.STATIC_DRAW)
  }

  val inputLayout = gl.createVertexArray() //#VertexArray# OpenGL dictionary:; vertex array object (VAO) is input layout
  init{
    gl.bindVertexArray(inputLayout)

    gl.bindBuffer(GL.ARRAY_BUFFER, vertexBuffer)
    gl.enableVertexAttribArray(0)
    gl.vertexAttribPointer(0, //#0# this explains how attribute 0 can be found in the vertex buffer
      3, GL.FLOAT, //< three pieces of float
      false, //< do not normalize (make unit length)
      0, //< tightly packed
      0 //< data starts at array start
    )

    gl.bindBuffer(GL.ARRAY_BUFFER, vertexColorBuffer)
    gl.enableVertexAttribArray(1)
    gl.vertexAttribPointer(1, //#0# this explains how attribute 1 can be found in the vertex buffer
      3, GL.FLOAT, //< three pieces of float
      false, //< do not normalize (make unit length)
      0, //< tightly packed
      0 //< data starts at array start
    )
    gl.bindVertexArray(null)
  }


  override fun draw() {

    gl.bindVertexArray(inputLayout)
    gl.bindBuffer(GL.ELEMENT_ARRAY_BUFFER, indexBuffer)  

    gl.drawElements(GL.TRIANGLES, 150, GL.UNSIGNED_SHORT, 0) //#3# pipeline is all set up, draw three indices worth of geometry
  }

}
